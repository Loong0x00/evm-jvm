package selectedcb0

// COPY-ONLY test observer. No accepted public API or guest/state injection.
import (
	"errors"
	"github.com/ethereum/go-ethereum/core/tracing"
)

func (s *Session) ParentTrace(h *tracing.Hooks) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if e := s.cb0Usable(); e != nil {
		return e
	}
	s.parentTrace = h
	return nil
}
func (s *Session) ParentPublicationFault(enable bool) error {
	s.mu.Lock()
	defer s.mu.Unlock()
	if e := s.cb0Usable(); e != nil {
		return e
	}
	s.testFault = nil
	if enable {
		s.testFault = func(p cb0FaultPoint) error {
			if p == cb0FaultAfterTrie {
				return errors.New("parent after real trie/code sync")
			}
			return nil
		}
	}
	return nil
}
