public class OrderProbe { public static int run(int x,int y){return x+y;} }
