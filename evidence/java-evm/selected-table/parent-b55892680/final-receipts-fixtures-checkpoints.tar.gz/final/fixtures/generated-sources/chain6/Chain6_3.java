public class Chain6_3 { static int s = 13; static { s += 103; } public static int run(int x) { return Chain6_4.run(x + s) + 3; } }
