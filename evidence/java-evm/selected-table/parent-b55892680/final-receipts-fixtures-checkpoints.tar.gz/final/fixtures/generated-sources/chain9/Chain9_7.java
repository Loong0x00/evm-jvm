public class Chain9_7 { static int s = 17; static { s += 107; } public static int run(int x) { return Chain9_8.run(x + s) + 7; } }
