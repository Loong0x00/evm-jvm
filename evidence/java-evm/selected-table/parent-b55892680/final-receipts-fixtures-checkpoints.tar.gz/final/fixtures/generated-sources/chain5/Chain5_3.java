public class Chain5_3 { static int s = 13; static { s += 103; } public static int run(int x) { return Chain5_4.run(x + s) + 3; } }
