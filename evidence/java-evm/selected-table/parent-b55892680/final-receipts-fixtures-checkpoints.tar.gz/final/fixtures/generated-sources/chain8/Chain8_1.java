public class Chain8_1 { static int s = 11; static { s += 101; } public static int run(int x) { return Chain8_2.run(x + s) + 1; } }
