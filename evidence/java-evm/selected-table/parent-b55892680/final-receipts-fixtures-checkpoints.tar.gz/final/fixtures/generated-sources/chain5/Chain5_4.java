public class Chain5_4 { static int s = 14; static { s += 104; } public static int run(int x) { return x + s; } }
