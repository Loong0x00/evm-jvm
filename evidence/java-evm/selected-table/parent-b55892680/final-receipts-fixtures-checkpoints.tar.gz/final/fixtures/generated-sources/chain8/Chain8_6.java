public class Chain8_6 { static int s = 16; static { s += 106; } public static int run(int x) { return Chain8_7.run(x + s) + 6; } }
