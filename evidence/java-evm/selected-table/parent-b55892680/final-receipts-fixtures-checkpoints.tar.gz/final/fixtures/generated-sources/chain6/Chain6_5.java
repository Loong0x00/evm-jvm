public class Chain6_5 { static int s = 15; static { s += 105; } public static int run(int x) { return x + s; } }
