public class Chain9_8 { static int s = 18; static { s += 108; } public static int run(int x) { return x + s; } }
