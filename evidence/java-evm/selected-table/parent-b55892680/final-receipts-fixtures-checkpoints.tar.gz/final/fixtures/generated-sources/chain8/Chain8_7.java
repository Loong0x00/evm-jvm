public class Chain8_7 { static int s = 17; static { s += 107; } public static int run(int x) { return x + s; } }
