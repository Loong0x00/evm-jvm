public class Chain8_4 { static int s = 14; static { s += 104; } public static int run(int x) { return Chain8_5.run(x + s) + 4; } }
