public class Chain8_2 { static int s = 12; static { s += 102; } public static int run(int x) { return Chain8_3.run(x + s) + 2; } }
