public class Chain5_1 { static int s = 11; static { s += 101; } public static int run(int x) { return Chain5_2.run(x + s) + 1; } }
