public class Chain9_6 { static int s = 16; static { s += 106; } public static int run(int x) { return Chain9_7.run(x + s) + 6; } }
