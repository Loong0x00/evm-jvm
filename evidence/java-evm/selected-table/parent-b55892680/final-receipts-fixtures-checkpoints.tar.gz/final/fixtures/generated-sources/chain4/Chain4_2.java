public class Chain4_2 { static int s = 12; static { s += 102; } public static int run(int x) { return Chain4_3.run(x + s) + 2; } }
