public class Chain6_4 { static int s = 14; static { s += 104; } public static int run(int x) { return Chain6_5.run(x + s) + 4; } }
