public class Chain4_1 { static int s = 11; static { s += 101; } public static int run(int x) { return Chain4_2.run(x + s) + 1; } }
