public class Chain4_3 { static int s = 13; static { s += 103; } public static int run(int x) { return x + s; } }
