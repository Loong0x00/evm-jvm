public class Chain9_5 { static int s = 15; static { s += 105; } public static int run(int x) { return Chain9_6.run(x + s) + 5; } }
