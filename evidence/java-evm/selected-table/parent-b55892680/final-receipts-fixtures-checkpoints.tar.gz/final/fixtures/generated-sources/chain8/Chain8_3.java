public class Chain8_3 { static int s = 13; static { s += 103; } public static int run(int x) { return Chain8_4.run(x + s) + 3; } }
