public class Chain9_2 { static int s = 12; static { s += 102; } public static int run(int x) { return Chain9_3.run(x + s) + 2; } }
