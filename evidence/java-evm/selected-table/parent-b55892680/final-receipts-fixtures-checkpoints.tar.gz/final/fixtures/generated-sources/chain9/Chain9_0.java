public class Chain9_0 { static int s = 10; static { s += 100; } public static int run(int x) { return Chain9_1.run(x + s) + 0; } }
