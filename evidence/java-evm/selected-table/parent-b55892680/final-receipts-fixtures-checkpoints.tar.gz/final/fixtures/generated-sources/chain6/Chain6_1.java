public class Chain6_1 { static int s = 11; static { s += 101; } public static int run(int x) { return Chain6_2.run(x + s) + 1; } }
