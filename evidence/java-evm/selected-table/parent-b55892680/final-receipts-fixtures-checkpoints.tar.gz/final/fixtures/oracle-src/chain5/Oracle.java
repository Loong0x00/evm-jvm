public class Oracle { public static void main(String[] a) { int mode = Integer.parseInt(a[0]); System.out.println("case=chain5 mode=" + mode + " result=" + Chain5_0.run(mode)); } }
