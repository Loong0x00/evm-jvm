public class Oracle { public static void main(String[] a) { int mode = Integer.parseInt(a[0]); System.out.println("case=capacity8-exact mode=" + mode + " result=" + Cap0.run(mode)); } }
