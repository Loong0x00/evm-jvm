public class Oracle { public static void main(String[] a) { int mode = Integer.parseInt(a[0]); System.out.println("case=aggregate262145 mode=" + mode + " result=" + BoundaryEntry.run(mode)); } }
