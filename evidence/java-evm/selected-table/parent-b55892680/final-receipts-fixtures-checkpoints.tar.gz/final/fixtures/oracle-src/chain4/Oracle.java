public class Oracle { public static void main(String[] a) { int mode = Integer.parseInt(a[0]); System.out.println("case=chain4 mode=" + mode + " result=" + Chain4_0.run(mode)); } }
