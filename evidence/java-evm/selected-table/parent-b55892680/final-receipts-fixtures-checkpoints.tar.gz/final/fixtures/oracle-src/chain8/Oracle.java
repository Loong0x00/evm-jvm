public class Oracle { public static void main(String[] a) { int mode = Integer.parseInt(a[0]); System.out.println("case=chain8 mode=" + mode + " result=" + Chain8_0.run(mode)); } }
