public class Oracle { public static void main(String[] a) { int mode = Integer.parseInt(a[0]); System.out.println("case=big-method-rich mode=" + mode + " result=" + BigCaller.run(mode)); } }
