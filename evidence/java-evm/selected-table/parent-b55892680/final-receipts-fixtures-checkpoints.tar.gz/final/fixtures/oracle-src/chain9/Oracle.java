public class Oracle { public static void main(String[] a) { int mode = Integer.parseInt(a[0]); System.out.println("case=chain9 mode=" + mode + " result=" + Chain9_0.run(mode)); } }
