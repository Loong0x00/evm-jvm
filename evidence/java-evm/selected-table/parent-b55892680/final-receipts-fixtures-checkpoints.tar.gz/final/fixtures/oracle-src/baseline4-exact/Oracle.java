public class Oracle { public static void main(String[] a) { int mode = Integer.parseInt(a[0]); System.out.println("case=baseline4-exact mode=" + mode + " result=" + Base0.run(mode)); } }
