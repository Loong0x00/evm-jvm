public class Oracle { public static void main(String[] a) { int mode = Integer.parseInt(a[0]); System.out.println("case=chain6 mode=" + mode + " result=" + Chain6_0.run(mode)); } }
