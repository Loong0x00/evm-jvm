public class AliasChild extends AliasBase {
    static int marker = 11;
    static { marker += 2; }
    public AliasChild(int x) { super(x + marker); }
    public int v(int x) { return super.v(x) + 17; }
    public int superV(int x) { return super.v(x); }

 public static int unused0(int x){return x+0;}
 public static int unused1(int x){return x+1;}
 public static int unused2(int x){return x+2;}
 public static int unused3(int x){return x+3;}
 public static int unused4(int x){return x+4;}
 public static int unused5(int x){return x+5;}
 public static int unused6(int x){return x+6;}
 public static int unused7(int x){return x+7;}
 public static int unused8(int x){return x+8;}
 public static int unused9(int x){return x+9;}
 public static int unused10(int x){return x+10;}
 public static int unused11(int x){return x+11;}
 public static int unused12(int x){return x+12;}
 public static int unused13(int x){return x+13;}
 public static int unused14(int x){return x+14;}
 public static int unused15(int x){return x+15;}
 public static int unused16(int x){return x+16;}
 public static int unused17(int x){return x+17;}
 public static int unused18(int x){return x+18;}
 public static int unused19(int x){return x+19;}
 public static int unused20(int x){return x+20;}
 public static int unused21(int x){return x+21;}
 public static int unused22(int x){return x+22;}
 public static int unused23(int x){return x+23;}
 public static int unused24(int x){return x+24;}
 public static int unused25(int x){return x+25;}
 public static int unused26(int x){return x+26;}
 public static int unused27(int x){return x+27;}
 public static int unused28(int x){return x+28;}
 public static int unused29(int x){return x+29;}
 public static int unused30(int x){return x+30;}
 public static int unused31(int x){return x+31;}
}
