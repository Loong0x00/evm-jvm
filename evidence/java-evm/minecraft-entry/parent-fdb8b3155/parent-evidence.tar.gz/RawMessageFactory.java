public interface RawMessageFactory {}
