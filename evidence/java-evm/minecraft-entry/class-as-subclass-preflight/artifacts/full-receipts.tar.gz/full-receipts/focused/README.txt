Durable checkpoint blobs and public EVM receipt JSON only. No LevelDB/state directory or Go binary.
